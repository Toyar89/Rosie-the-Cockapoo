Rosie Video Call Page

This is a smartphone-only incoming video call style page.

Files included:
- index.html
- style.css
- script.js
- rosie-photo.png
- rosie-message.mp4

How to use:
1. Upload all files to your website or GitHub Pages.
2. Open index.html on a phone.
3. Tap Answer and the Rosie video will play.

Personalised name trick:
Add ?name=Sarah to the URL.

Example:
index.html?name=Sarah

This changes the incoming screen to:
Special message for Sarah

To use a different video:
Replace rosie-message.mp4 with another MP4 using the same file name.

To use a different photo:
Replace rosie-photo.png with another image using the same file name.
